let store = {
    cart_products: [],
};

export default store